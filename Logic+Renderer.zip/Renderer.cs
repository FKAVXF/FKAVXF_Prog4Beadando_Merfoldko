﻿namespace Penguin.Renderer
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using Penguin.Logic;
    using Penguin.Model;

    /// <summary>
    /// Renderer class for the game.
    /// </summary>
    public class Renderer
    {

        /// <summary>
        /// Method for background.
        /// </summary>
        /// <returns> Returns background brush.</returns>
        public Brush GetBackgroundBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.background.png");
        }

        /// <summary>
        /// Method for background.
        /// </summary>
        /// <returns> Returns background brush.</returns>
        public Brush GetNewGameBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.newgame.png");
        }

        /// <summary>
        /// Method for penguin front.
        /// </summary>
        /// <returns> Returns penguin brush.</returns>
        public Brush GetPenguinFrontBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.penguin_front_0.png");
        }

        /// <summary>
        /// Method for penguin back.
        /// </summary>
        /// <returns> Returns penguin brush.</returns>
        public Brush GetPenguinBackBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.penguin_back_0.png");
        }

        /// <summary>
        /// Method for penguin left side.
        /// </summary>
        /// <returns> Returns penguin brush.</returns>
        public Brush GetPenguinLeftBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.penguin_left_0.png");
        }

        /// <summary>
        /// Method for penguin right side.
        /// </summary>
        /// <returns> Returns penguin brush.</returns>
        public Brush GetPenguinRightBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.penguin_right_0.png");
        }

        /// <summary>
        /// Method for table.
        /// </summary>
        /// <returns> Returns table brush.</returns>
        public Brush GetTableBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.table.png");
        }

        /// <summary>
        /// Method for chair.
        /// </summary>
        /// <returns> Returns chair brush.</returns>
        public Brush GetChairBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.chair.png");
        }

        /// <summary>
        /// Method for pizza.
        /// </summary>
        /// <returns> Returns pizza brush.</returns>
        public Brush GetPizzaBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.pizza.png");
        }

        /// <summary>
        /// Method for burger.
        /// </summary>
        /// <returns> Returns burger brush.</returns>
        public Brush GetBurgerBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.burger.png");
        }

        /// <summary>
        /// Method for fish.
        /// </summary>
        /// <returns> Returns fish brush.</returns>
        public Brush GetFishBrush()
        {
            return this.GetBrush("Penguin.Renderer.Images.fish.png");
        }

        private Brush GetBrush(string fname)
        {
            BitmapImage bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.StreamSource = Assembly.GetExecutingAssembly().GetManifestResourceStream(fname);
            bmp.EndInit();
            ImageBrush ib = new ImageBrush(bmp);
            return ib;
        }

        /*public Renderer()
        {
            this.myModel = model;
        }

        Model myModel;

        Drawing oldBackground;
        Drawing oldPlayerPenguin;

        Point oldPlayerPenguinPosition;

        //List<Drawing> oldCustomerPenguins;
        //List<Point> oldCustumerPenguinPositions;
        Dictionary<Drawing, Point> oldCustomerPenguinWithPositions;

        /// <summary>
        /// Resets the stored objects before new level.
        /// </summary>
        public void Reset()
        {
            this.oldBackground = null;
            this.oldPlayerPenguin = null;
            this.oldPlayerPenguinPosition = new Point(-1, -1);
        }

        public Drawing BuildDrawing()
        {
            DrawingGroup drawingGroup = new DrawingGroup();
            drawingGroup.Children.Add(this.GetBackground());
            drawingGroup.Children.Add(this.GetTablesAndChairs());
            drawingGroup.Children.Add(this.GetPlayerPenguin());
            drawingGroup.Children.Add(this.GetCustomerPenguins());
            drawingGroup.Children.Add(this.GetFood());

            return drawingGroup;
        }

        public Drawing GetBackground()
        {
            if (this.oldBackground == null)
            {
                Geometry backgroundGeometry = new RectangleGeometry(new Rect(0, 0, this.myModel.GameWidth, this.myModel.GameHeight));
                this.oldBackground = new GeometryDrawing(this.myModel.FillBrush, null, backgroundGeometry);
            }

            return this.oldBackground;
        }

        private Drawing GetTablesAndChairs()
        {
            throw new NotImplementedException();
        }

        private Drawing GetPlayerPenguin()
        {
            //point is kellhet a pingukának
            if (this.oldPlayerPenguin == null || this.oldPlayerPenguinPosition != new Point(this.myModel.PlayerPenguin.CX, this.myModel.PlayerPenguin.CY))
            {
                // size pingunak<3
                Geometry playerPingu = new RectangleGeometry(new Rect(this.myModel.PlayerPenguin.CX, this.myModel.PlayerPenguin.CX, 10, 10));
                this.oldPlayerPenguin = new GeometryDrawing(this.myModel.PlayerPenguin.FillBrush, null, playerPingu);
                this.oldPlayerPenguinPosition = new Point(this.myModel.PlayerPenguin.CX, this.myModel.PlayerPenguin.CY);
            }

            return this.oldPlayerPenguin;
        }

        private Drawing GetCustomerPenguins()
        {
            throw new NotImplementedException();
        }

        private Drawing GetFood()
        {
            throw new NotImplementedException();
        }*/
    }
}
