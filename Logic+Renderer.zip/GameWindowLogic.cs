﻿// <copyright file="GameWindowLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Penguin.Logic
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Penguin.Model;

    /// <summary>
    /// A játék főablakának logicja.
    /// </summary>
    public class GameWindowLogic
    {
        public PlayerPenguin player;
        private int tableCount;
        public List<Table> tables;
        public List<Table> occupiedTables;
        private List<CustomerPenguin> customers;
        private Random rnd = new Random();

        /// <summary>
        /// Initializes a new instance of the <see cref="GameWindowLogic"/> class.
        /// Beolvassa a felhasználó adatait.
        /// </summary>
        /// <param name="user">Felhasználó akivel játszani akarunk.</param>
        /// <param name="tablePositionsX">Asztalok x pozícióját tartalmazó tömb.</param>
        /// <param name="tablePositionsY">Asztalok y pozícióját tartalmazó tömb.</param>
        public GameWindowLogic()
        {
            //this.player = player;
            //this.tableCount = this.User.RestaurantUpgrades;
            //this.tables = this.MakingTableList(tablePositionsX, tablePositionsY);
        }

        public bool IsColliding(GameItem itemOne, GameItem itemTwo)
        {
            if (itemOne.Area.IntersectsWith(itemTwo.Area))
            {
                return true;
            }

            return false;
        }
        /*public bool IsCollidingWithTable(GameItem pengi)
        {
            foreach (var item in TablePosition())
            {
                //Table table = new Table(item[0], item[1], 50, 45);
                if (pengi.Area.X == item[0])
                {
                    return true;
                }
            }
            return false;
        }*/

        public bool FreeTable()
        {
            return occupiedTables.Count < tables.Count;
        }

        public void MoveUp(GameItem item, double border)
        {
            if (item.Area.Y >= border)
            {
                item.ChangeY(-5);
            }
        }
        public void MoveDown(GameItem item, double border)
        {
            if (item.Area.Y <= border)
            {
                item.ChangeY(5);
            }
        }

        public void MoveLeft(GameItem item, double border)
        {
            if (item.Area.X >= border)
            {
                item.ChangeX(-5);
            }
        }

        public void MoveRight(GameItem item, double border)
        {
            if (item.Area.X <= border)
            {
                item.ChangeX(5);
            }
        }

        public List<int[]> TablePosition()
        {
            List<int[]> tempList = new List<int[]>();
            for (int i = 1; i < 4; i++)
            {
                for (int j = 1; j < 4; j++)
                {
                    int[] temp = new int[2];
                    temp[0] = i * 150;
                    temp[1] = j * 100;
                    tempList.Add(temp);
                }
            }

            return tempList;
        }

        /// <summary>
        /// Gets or sets játékos.
        /// </summary>
        public User User { get; set; }

        /// <summary>
        /// Megmondja elfogytak-e a vendégek.
        /// </summary>
        /// <returns>Üres-e a vedngédek lista.</returns>
        public bool LevelEnd()
        {
            return this.customers.Count < 1;
        }

        /*private Table MakingTable(double startPosX, double startPosY)
        {
            double r = 10; // székek asztaltól való távolsága
            Table tempTable = new Table(startPosX, startPosY);
            switch (this.rnd.Next(0, 2) < 1)
            {
                case true:
                    tempTable.Chairs.Add(new Chair(startPosX + r, startPosY));
                    break;
                case false:
                    tempTable.Chairs.Add(new Chair(startPosX + r, startPosY));
                    tempTable.Chairs.Add(new Chair(startPosX - r, startPosY));
                    break;
            }

            return tempTable;
        }

        /// <summary>
        /// Létrehozza a asztal listát.
        /// </summary>
        /// <param name="tablePositionsX">Asztalok x pozícióját tartalmazó tömb.</param>
        /// <param name="tablePositionsY">Asztalok y pozícióját tartalmazó tömb.</param>
        private List<Table> MakingTableList(double[] tablePositionsX, double[] tablePositionsY)
        {
            List<Table> tempTables = new List<Table>();
            for (int i = 0; i < this.tableCount; i++)
            {
                tempTables.Add(this.MakingTable(tablePositionsX[i], tablePositionsY[i]));
            }

            return tempTables;
        }*/

        /// <summary>
        /// Feladatok elvégzésének metódusa.
        /// </summary>
        public void DoTask()
        {

        }
    }
}
