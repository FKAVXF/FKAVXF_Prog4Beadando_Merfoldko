﻿// <copyright file="PauseScreenLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Penguin.Logic
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Penguin.Model;
    using Penguin.Repository;

    /// <summary>
    /// 2 level közötti képernyő logicja.
    /// </summary>
    public class PauseScreenLogic : IPauseScreenLogic
    {
        private IRepository repository;

    /// <summary>
    /// Initializes a new instance of the <see cref="PauseScreenLogic"/> class.
    /// </summary>
    /// <param name="user">Játékos.</param>
    /// <param name="repository">Repo.</param>
        public PauseScreenLogic(User user, IRepository repository)
        {
            this.User = user;
            this.repository = repository;
        }

        /// <summary>
        /// Gets or sets jelenlegi játékos.
        /// </summary>
        public User User { get; set; }

        /// <summary>
        /// Elmenti a felhasználó adatait.
        /// </summary>
        /// <param name="data">Felhasználó.</param>
        public void Save()
        {
             this.repository.Create(this.User);
        }

        /// <summary>
        /// A bolt logicja.
        /// </summary>
        /// <param name="upgrades">Az éttermet vagy a felszolgálót akarja fejleszteni a játékos.</param>
        /// <param name="cost">A fejlesztés ára.</param>
        public void Shop(string upgrades, int cost)
        {
            this.User.Money -= cost;
            switch (upgrades)
            {
                case "Player":
                    this.User.PlayerUpgrades++;
                    break;
                case "Restaurant":
                    this.User.RestaurantUpgrades++;
                    break;
            }
        }
    }
}
