﻿// <copyright file="NewGameLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Penguin.Logic
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Penguin.Model;

    /// <summary>
    /// Új játék kezdetekor, új játékos létrehozása.
    /// </summary>
    internal class NewGameLogic : INewGameLogic
    {
        private readonly Random rnd = new Random();

        /// <summary>
        /// Initializes a new instance of the <see cref="NewGameLogic"/> class.
        /// </summary>
        /// <param name="name">Játékos neve.</param>
        /// <param name="imgUrl">Játékos képének az url-je.</param>
        /// <param name="saveSlot">Hányas mentés slotot választotta.</param>
        public NewGameLogic(string name, string imgUrl, int saveSlot)
        {
            this.User = new User(saveSlot)
            {
                ID = this.rnd.Next(1, 3000000).ToString(),
                Name = name,
                ImgUrl = imgUrl,
                SaveSlot = saveSlot,
                Level = 0,
                Money = 0,
                PlayerUpgrades = 0,
                RestaurantUpgrades = 0,
            };
        }

        /// <summary>
        /// Gets A játékost akit majd beletolunk a rendszerbe.
        /// </summary>
        public IModel User { get; }
    }
}
