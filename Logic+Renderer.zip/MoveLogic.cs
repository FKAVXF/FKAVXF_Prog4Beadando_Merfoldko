﻿// <copyright file="MoveLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Penguin.Logic
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Penguin.Model;

    /// <summary>
    /// A mozgókarakterek mozgásának logicja.
    /// </summary>
    public class MoveLogic //: IMoveLogic
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="MoveLogic"/> class.
        /// Movelogic kontruktora.
        /// </summary>
        /// <param name="user">Felhasználó akivel játszunk.</param>
        /// <param name="giJoe">Mozgatni kívánt elem.</param>
        public MoveLogic()
        {
        }

        

        
    }
}
