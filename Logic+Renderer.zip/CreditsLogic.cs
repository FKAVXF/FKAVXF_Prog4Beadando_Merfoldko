﻿// <copyright file="CreditsLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Penguin.Logic
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Penguin.Model;

    /// <summary>
    /// Kredit lista osztálya.
    /// </summary>
    public class CreditsLogic //: ICreditsLogic
    {

        List<Makers> bestTeam { get; }


        /// <summary>
        /// Initializes a new instance of the <see cref="CreditsLogic"/> class.
        /// </summary>
        /// <param name="bestTeam">Csapat tagjait tartalmazó lista.</param>
        public CreditsLogic(List<Makers> bestTeam)
        {
            this.bestTeam = bestTeam;
        }

        /// <summary>
        /// Visszaadja a készítők listáját.
        /// </summary>
        /// <returns>Credit lista.</returns>
        public List<Makers> GetProgrammers()
        {
            return this.bestTeam;
        }
    }
}
