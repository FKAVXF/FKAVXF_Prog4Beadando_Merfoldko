﻿// <copyright file="LoadGameLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Penguin.Logic
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using Penguin.Model;
    using Penguin.Repository;

    /// <summary>
    /// Betölti az egyik elmentett felhasználót.
    /// </summary>
    public class LoadGameLogic : ILoadGameLogic
    {
        private readonly IRepository repository;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoadGameLogic"/> class.
        /// </summary>
        /// <param name="repository">A repoó ami kell.</param>
        public LoadGameLogic(IRepository repository)
        {
            this.repository = repository;
        }

        /// <summary>
        /// Visszaadja a betölteni kívánt játékos adatait, egy string tömbben.
        /// </summary>
        /// <param name="url">A betölteni kívánt játékos fájlja.</param>
        /// <returns>Betölteni kívánt játékos adatai egy string tömbben.</returns>
        public User LoadGame(string url)
        {
            return this.repository.Read(url);
        }
    }
}