﻿// <copyright file="HighScoreLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Penguin.Logic
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Penguin.Model;
    using Penguin.Repository;

    /// <summary>
    /// Highscore business logic.
    /// </summary>
    internal class HighScoreLogic //: IHighScoreLogic
    {
        private readonly Repository repository = new Repository();
        private readonly List<User> highScores;

        /// <summary>
        /// Initializes a new instance of the <see cref="HighScoreLogic"/> class.
        /// </summary>
        public HighScoreLogic()
        {
            this.highScores = this.repository.HighScoreRead();
        }

        /// <summary>
        /// Visszaadja a highscore tömböt.
        /// </summary>
        /// <returns>Highscore tömb.</returns>
        public List<User> GetHighScores()
        {
            return this.highScores;
        }
    }
}
